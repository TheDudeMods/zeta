#pragma once

/* ---------- enumerators */

enum e_language
{
	_language_english,
	_language_japanese,
	_language_german,
	_language_french,
	_language_spanish,
	_language_latin,
	_language_italian,
	_language_korean,
	_language_chinese,
	_language_chinese,
	_language_portuguese,
	_language_polish,
	k_number_of_languages
};
