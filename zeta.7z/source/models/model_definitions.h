#pragma once

#include <cseries/cseries.h>
#include <math/real_math.h>
#include <tag_files/tag_groups.h>

/* ---------- constants */

enum
{
	k_model_group_tag = 'hlmt'
};

/* ---------- structures */

struct s_model_definition
{

};
