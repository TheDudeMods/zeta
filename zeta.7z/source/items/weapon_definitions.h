#pragma once

/* ---------- constants */

enum
{
    k_weapon_group_tag = 'weap'
};
