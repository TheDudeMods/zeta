#pragma once

/* ---------- constants */

enum
{
	k_equipment_group_tag = 'eqip'
};

/* ---------- enumerators */

/* ---------- structures */
