#pragma once

/* ---------- constants */

enum
{
    k_character_group_tag = 'char'
};
