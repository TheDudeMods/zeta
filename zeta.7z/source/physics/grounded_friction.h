#pragma once

/* ---------- constants */

enum
{
    k_grounded_friction_group_tag = 'grfr'
};
