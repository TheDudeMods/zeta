#pragma once

/* ---------- constants */

enum
{
	k_collision_damage_group_tag = 'cddf'
};
