#pragma once

/* ---------- constants */

enum
{
    k_spring_acceleration_group_tag = 'sadt'
};
