#pragma once

#include <cseries/cseries.h>

/* ---------- constants */

enum
{
	k_simulation_interpolation_group_tag = 'siin'
};
