#pragma once

/* ---------- constants */

enum
{
	k_effect_group_tag = 'effe'
};
