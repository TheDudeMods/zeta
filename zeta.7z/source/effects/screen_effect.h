#pragma once

/* ---------- constants */

enum
{
    k_area_screen_effect_group_tag = 'sefc'
};
