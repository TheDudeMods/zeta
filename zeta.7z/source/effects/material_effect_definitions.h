#pragma once

/* ---------- constants */

enum
{
	k_material_effects_group_tag = 'foot'
};
