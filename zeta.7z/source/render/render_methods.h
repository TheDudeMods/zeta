#pragma once

/* ---------- constants */

enum
{
    k_render_method_group_tag = 'rm  ',
};
