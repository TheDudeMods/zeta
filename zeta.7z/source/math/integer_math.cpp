/*
INTEGER_MATH.CPP
*/

#include <math/integer_math.h>

/* ---------- code */
