#pragma once

/* ---------- constants */

enum
{
	k_sound_group_tag = 'snd!',
	k_sound_looping_group_tag = 'lsnd',
};
