#pragma once

#include <cseries/cseries.h>
#include <tag_files/tag_groups.h>

/* ---------- constants */

enum
{
    k_damage_effect_group_tag = 'jpt!'
};
