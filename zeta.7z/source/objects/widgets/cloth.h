#pragma once

/* ---------- constants */

enum
{
	k_clothwind_group_tag = 'clwd'
};
