#pragma once

/* ---------- constants */

enum
{
	k_antenna_group_tag = 'ant!'
};
