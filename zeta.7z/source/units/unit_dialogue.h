#pragma once

/* ---------- constants */

enum
{
    k_unit_dialogue_group_tag = 'udlg'
};
