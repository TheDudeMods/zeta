#pragma once

/* ---------- constants */

enum
{
    k_chud_definition_group_tag = 'chdt'
};
